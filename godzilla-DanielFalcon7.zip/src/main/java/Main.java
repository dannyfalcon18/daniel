public class Main {
  public static void main(String[] args) {
    Monster monster1 = new Monster("Kong", 150);
    Monster monster2 = new Monster("Zilla", 100);

    monster1.attack();
    monster2.attack();

    monster1.setName("Kong");
    monster1.setLevel(100);

    monster1.attack();
  }
}
